jQuery(document).ready(function () {
    $('.indicator_all ul li').click(function () {
        $('.indicator_all ul li').removeClass('active');
        $(this).addClass('active');
    })

    // Owl Carousel
    var owl = $(".slider_menu");
    owl.owlCarousel({
        margin: 0,
        loop: true,
        autoplay: false,
        nav: false,
        dots: false,
        items: 1
    });


    // Go to the next item
    $('.next').click(function () {
        owl.trigger('next.owl.carousel');
    })
    // Go to the previous item
    $('.prev').click(function () {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        owl.trigger('prev.owl.carousel', [300]);
    })
})